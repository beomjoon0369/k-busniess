const express = require('express');
const engines = require('consolidate');
const ejs = require('ejs');
const fs = require('fs');
const path = require('path');
const app = express();
const router = express.Router();
const bodyParser = require('body-parser');
const cors = require('cors');
const urlencode = require('urlencode');

// 뷰엔진 설정
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


// 미들웨어 설정
app.use(bodyParser.urlencoded({
    extended: false
}));


//------- Cloud Firestore 데이터베이스 초기화 --------
//서버내에서 인증 할 경우 ...
//const admin = require('firebase-admin');
//const functions = require('firebase-functions');
//admin.initializeApp(functions.config().firebase);
//var db = admin.firestore();

//서버 외부에서 인증 할 경우 ...
const admin = require('firebase-admin');
const firebase = admin;
const functions = require('firebase-functions');
///다운로드 받은 인증파일:  k-busniess-f8323bbf8d34.json
//var serviceAccount = require('path/to/serviceAccountKey.json');
var serviceAccount = require('./k-busniess-f8323bbf8d34.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

var db = admin.firestore();


///// 시퀀스 관련 공통 함수
///// count
function getCollectionReg(_id, callback) {
    let cityRef = db.collection('collection_reg').doc(_id);
    let getDoc = cityRef.get().then(doc => {
        if (!doc.exists) {
            console.log('No such document!');
        } else {
            //console.log('Document data:', doc.data());
            let docData = doc.data();
            docData._id = _id;
            callback(docData);
        }
    }).catch(err => {
        console.log('Error getting document');
    });
}

function setCollectionReg(_id, data) {
    //console.log("userData => ", userData);
    var usersRef = db.collection('collection_reg').doc(_id);

    // Set the field of the users
    var updateSingle = usersRef.update(data);
}


///////////
//################### users 입출력 기능 #####
router.route('/user').post((req, res) => {
    //console.log('/user -post 호출 됨');
    getCollectionReg("users_reg", function (regData) {
        var user = {
            no: regData.no_cnt,
            id: req.body.id,
            name: req.body.name,
            region: req.body.region,
            password: req.body.password
        }

        //var docRef = db.collection('users').doc();
        //var setAda = docRef.set(user);

        // Add a new document with a generated id.
        var addDoc = db.collection('users').add(user).then(ref => {
            //console.log('Added document with ID: ', ref.id);
            //res.end('/user - inserted ...');
            setCollectionReg("users_reg", {
                'no_cnt': regData.no_cnt + 1
            });
            res.redirect('/user');
        }).catch((err) => {
            //console.log('Error add documents', err);
            res.end('/user - add error ...');
        });
    });

});

router.route('/user').get((req, res) => {
    //console.log('/user get요청 받음.');

    var userList = [];

    db.collection('users').get().then((snapshot) => {
        snapshot.forEach((doc) => {
            //console.log(doc.id, '=>', doc.data());
            //console.log(doc._fieldsProto);
            userList.push({
                _id: doc.id,
                id: doc._fieldsProto.id.stringValue,
                name: doc._fieldsProto.name.stringValue,
                region: doc._fieldsProto.region.stringValue,
            });
            var docData = doc.data();
            userList.push({
                _id: doc.id,
                id: docData.id,
                name: docData.name,
                region: docData.region,
            });
        });
        //console.log('user_list >>> ', userList);
        req.app.render('user_list', {
            "userList": userList
        }, (err, html) => {
            if (err) {
                throw err;
            }
            res.end(html);
        });
    }).catch((err) => {
        //console.log('Error getting documents', err);
        res.end('error!');
    });
});

router.route('/user/:_id').get((req, res) => {
    let _id = req.params._id;
    //console.log("상세보기 _id => ", _id);

    let cityRef = db.collection('users').doc(_id);
    let getDoc = cityRef.get().then(doc => {
        if (!doc.exists) {
            //console.log('No such document!');
            res.end('No such document!');
        } else {
            //console.log('Document data:', doc.data());
            let docData = doc.data();
            docData._id = _id;
            req.app.render('user_detail', {
                'user': docData
            }, function (err, html) {
                res.end(html);
            });
        }
    }).catch(err => {
        //console.log('Error getting document', err);
        res.end('Error getting document');
    });
});

router.route('/user/:_id/modify').get((req, res) => {
    var _id = req.params._id;
    //console.log("_id => ", _id);
    var usersRef = db.collection('users').doc(_id);
    var getDoc = usersRef.get().then(doc => {
        if (!doc.exists) {
            //console.log('No such document!');
            res.writeHead(200, {
                'Content-Type': 'text/html;charset=utf-8'
            });
            res.end("<h2>수정하고자 하는 사용자의 정보가 없습니다!</h2>");
        } else {
            //console.log('Document data:', doc.data());
            var userData = doc.data();
            userData._id = _id;
            req.app.render('user_modify', {
                "user": userData
            }, (err, html) => {
                if (err) throw err;
                res.end(html);
            });
        }
    }).catch(err => {
        res.end('Error getting document', err);
    });
});

router.route('/user/:_id/update').post((req, res) => {
    var _id = req.params._id;
    //console.log("_id => ", _id);

    let userData = {
        id: urlencode.decode(req.body.id || req.query.id),
        name: urlencode.decode(req.body.name || req.query.name),
        region: urlencode.decode(req.body.region || req.query.region)
    }
    //console.log("userData => ", userData);
    var usersRef = db.collection('users').doc(_id);

    // Set the field of the users
    var updateSingle = usersRef.update(userData);

    res.redirect('/user');
});

router.route('/user/:_id/delete').get((req, res) => {
    var _id = req.params._id;
    console.log("_id => ", _id);

    var deleteDoc = db.collection('users').doc(_id).delete();

    res.writeHead('200', {
        'Content-Type': 'text/html;charset=utf8'
    });
    res.write('<h3>삭제 성공!</h3>');
    res.write('<p><a href="/user">목록으로 이동</a></p>');
    res.end();
});



///////////
// ################### accept 입출력 기능 #####
// 수강 신정 기능
// 수강 신청자 목록
// 수강 신청시 관리자에게 자동 이메일 발송
// 1. 수강 신청 목록 폼
// 2. 신청서 접수 목록
/*
{
    address : "서울시 은평구 응암동",
    course : "일반경비원 신임교육육",
    jumin : "750101-1111111",
    mobile : "010-1111-1111",
    name : "홍길동",
    no : 1,
    payment : "card",
    phone : "02-123-4567",
    reg_date : "2019-06-15",
    type : "series"
}
*/




router.route('/accept').post((req, res) => {
    getCollectionReg("accept_reg", function (regData) {
        var acceptData = {
            address: req.body.address,
            course: "일반경비원 신임교육",
            jumin: req.body.jumin1 + "-" + req.body.jumin2,
            mobile: req.body.mobile,
            name: req.body.name,
            no: regData.no_cnt,
            payment: req.body.payment,
            phone: req.body.phone,
            reg_date: new Date(),
            type: req.body.type
        }

        var addDoc = db.collection('accept').add(acceptData).then(ref => {
            setCollectionReg("accept_reg", {
                'no_cnt': regData.no_cnt + 1
            });
            var _id = ref.id;
            console.log('등록 성공 _id => ', _id);

            res.redirect('/accept_insert_ok/' + _id);
        }).catch((err) => {
            res.end('/accept - add error ...');
        });
    });
});

router.route('/accept_insert_ok/:_id').get(function (req, res) {
    var _id = req.params._id;
    let cityRef = db.collection('accept').doc(_id);
    let getDoc = cityRef.get().then(doc => {
        if (!doc.exists) {
            //console.log('No such document!');
            res.end('No such accept document!');
        } else {
            //console.log('Document data:', doc.data());
            let docData = doc.data();
            docData._id = _id;
            req.app.render('accept_insert_ok', {
                'docData': docData
            }, function (err, html) {
                res.end(html);
            });
        }
    }).catch(err => {
        //console.log('Error getting document', err);
        res.end('Error accept getting document');
    });
});

router.route('/accept').get((req, res) => {
    //console.log('/user get요청 받음.');
    var acceptList = [];

    db.collection('accept').get().then((snapshot) => {
        snapshot.forEach((doc) => {
            var docData = doc.data();
            acceptList.push({
                _id: doc.id,
                address: docData.address,
                course: docData.course,
                jumin: docData.jumin,
                mobile: docData.mobile,
                name: docData.name,
                no: docData.no,
                payment: docData.payment,
                phone: docData.phone,
                reg_date: docData.reg_date,
                type: docData.type
            });
        });
        //console.log('acceptList >>> ', acceptList);
        req.app.render('accept_list', {
            "acceptList": acceptList
        }, (err, html) => {
            if (err) {
                throw err;
            }
            res.end(html);
        });
    }).catch((err) => {
        //console.log('Error getting documents', err);
        res.end('accept error!');
    });
});


router.route('/admin/login').post(function (req, res) {
    var id = req.body.id;
    var password = req.body.password;

    // Create a reference to the cities collection
    var usersRef = db.collection('users');

    // 컬렉션에서 필드값 복합 검색
    var query = usersRef.where('id', '==', id).where('password', '==', password).get()
        .then(snapshot => {
            if(snapshot.size == 0) {
                res.writeHead('200', {'Content-Type':'text/html;charset=utf8'});
                res.write('<h3>No such user ...</h3>');
                res.write('<p><a href="/admin_login.html">관리자 로그인 페이지로 이동</a></p>');
            } else {
                snapshot.forEach(doc => {
                    //console.log(doc.id, '=>', doc.data());
                    //res.end(doc.id + '=>' + JSON.stringify(doc.data() ));
                    var docData = doc.data();
                    if(docData.id == 'admin') {
                        res.redirect('/accept');
                    }else{
                        res.writeHead('200', {'Content-Type':'text/html;charset=utf8'});
                        res.write('<h3>경고: 관리자가 아닙니다!</h3>');
                        res.write('<p><a href="/admin_login.html">관리자 로그인 페이지로 이동</a></p>');
                    }
                });
            } 
        }).catch(err => {
            console.log('Error getting documents', err);
            res.end('Error getting documents' + JSON.stringify(err));
        });


    /*// Create a query against the collection
    var queryRef = usersRef.where('id', '==', id).where('password', '==', password);
    console.dir(queryRef);

    var observer = queryRef.onSnapshot(querySnapshot => {
        console.log(`Received query snapshot of size ${querySnapshot.size}`);
        //observer();
        //console.dir(querySnapshot);
        //res.end(JSON.stringify(querySnapshot));
        res.end('Received query snapshot ...');
    }, err => {
        console.log(`Encountered error: ${err}`);
        res.end('`Encountered error');
    });*/
});


// 라우터 미들웨어 설정
app.use('/', router);
// 모듈에 등록
module.exports.app = functions.https.onRequest(app);



/*
url 한글 인코딩 문제 해결 ...
1. 먼저 설치! npm install urlencode
2. 사용법은 간단합니다. urlencode() 자체가  utf-8 이 디폴트이기 때문에 따로 설정도 필요없이 바로 넣어주면 됩니다. 
var urlencode = require('urlencode');

console.log(urlencode('변환'));
console.log(urlencode.decode('%EB%B3%80%ED%99%98'));
*/
