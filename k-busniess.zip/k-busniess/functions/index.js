const express = require('express');
const engines = require('consolidate');
const ejs = require('ejs');
const fs = require('fs');
const path = require('path');
const app = express();
const router = express.Router();
const bodyParser = require('body-parser');
const cors = require('cors');
const urlencode = require('urlencode');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({
    extended: false
}));


//------- Cloud Firestore 초기화 --------
//const admin = require('firebase-admin');
const functions = require('firebase-functions');
//admin.initializeApp(functions.config().firebase);
//var db = admin.firestore();

//
/// k-busniess-f8323bbf8d34.json
const admin = require('firebase-admin');
//var serviceAccount = require('path/to/serviceAccountKey.json');
var serviceAccount = require('./k-busniess-f8323bbf8d34.json');

admin.initializeApp({
    credential: admin.credential.cert(serviceAccount)
});

var db = admin.firestore();



router.route('/user').post((req, res) => {
    //console.log('/user -post 호출 됨');

    var user = {
        id: req.body.id,
        name: req.body.name,
        region: req.body.region,
        password: req.body.password
    }

    //var docRef = db.collection('users').doc();
    //var setAda = docRef.set(user);

    // Add a new document with a generated id.
    var addDoc = db.collection('users').add(user).then(ref => {
        //console.log('Added document with ID: ', ref.id);
        //res.end('/user - inserted ...');
        res.redirect('/user');
    }).catch((err) => {
        //console.log('Error add documents', err);
        res.end('/user - add error ...');
    });
});

router.route('/user').get((req, res) => {
    //console.log('/user get요청 받음.');

    var userList = [];

    db.collection('users').get().then((snapshot) => {
        snapshot.forEach((doc) => {
            //console.log(doc.id, '=>', doc.data());
            //console.log(doc._fieldsProto);
            userList.push({
                _id: doc.id,
                id: doc._fieldsProto.id.stringValue,
                name: doc._fieldsProto.name.stringValue,
                region: doc._fieldsProto.region.stringValue,
            });
            var docData = doc.data();
            userList.push({
                _id: doc.id,
                id: docData.id,
                name: docData.name,
                region: docData.region,
            });
        });
        //console.log('user_list >>> ', userList);
        req.app.render('user_list', {
            "userList": userList
        }, (err, html) => {
            if (err) {
                throw err;
            }
            res.end(html);
        });
    }).catch((err) => {
        //console.log('Error getting documents', err);
        res.end('error!');
    });


});

router.route('/user/:_id').get((req, res) => {
    let _id = req.params._id;
    //console.log("상세보기 _id => ", _id);

    let cityRef = db.collection('users').doc(_id);
    let getDoc = cityRef.get().then(doc => {
        if (!doc.exists) {
            //console.log('No such document!');
            res.end('No such document!');
        } else {
            //console.log('Document data:', doc.data());
            let docData = doc.data();
            docData._id = _id;
            req.app.render('user_detail', {
                'user': docData
            }, function (err, html) {
                res.end(html);
            });
        }
    }).catch(err => {
        //console.log('Error getting document', err);
        res.end('Error getting document');
    });
});

router.route('/user/:_id/modify').get((req, res) => {
    var _id = req.params._id;
    //console.log("_id => ", _id);
    var usersRef = db.collection('users').doc(_id);
    var getDoc = usersRef.get().then(doc => {
        if (!doc.exists) {
            //console.log('No such document!');
            res.writeHead(200, {
                'Content-Type': 'text/html;charset=utf-8'
            });
            res.end("<h2>수정하고자 하는 사용자의 정보가 없습니다!</h2>");
        } else {
            //console.log('Document data:', doc.data());
            var userData = doc.data();
            userData._id = _id;
            req.app.render('user_modify', {"user": userData}, (err, html) => {
                if (err) throw err;
                res.end(html);
            });
        }
    }).catch(err => {
        res.end('Error getting document', err);
    });
});

router.route('/user/:_id/update').get((req, res) => {
    var _id = req.params._id;
    //console.log("_id => ", _id);
    
    let userData = {
        id: urlencode.decode(req.body.id),
        name: urlencode.decode(req.body.name || req.query.name),
        region: urlencode.decode(req.body.region || req.query.region)
    }
    //console.log("userData => ", userData);
    var usersRef = db.collection('users').doc(_id);

    // Set the field of the users
    var updateSingle = usersRef.update(userData);

    res.redirect('/user');
});

router.route('/user/:_id/delete').get((req, res) => {
    var _id = req.params._id;
    console.log("_id => ", _id);
    
    var deleteDoc = db.collection('users').doc(_id).delete();

    res.writeHead('200', {'Content-Type':'text/html;charset=utf8'});
    res.write('<h3>삭제 성공!</h3>');
    res.write('<p><a href="/user">목록으로 이동</a></p>');
    res.end();
});

app.use('/', router);

module.exports.app = functions.https.onRequest(app);



/*
url 한글 인코딩 문제 해결 ...
1. 먼저 설치! npm install urlencode
2. 사용법은 간단합니다. urlencode() 자체가  utf-8 이 디폴트이기 때문에 따로 설정도 필요없이 바로 넣어주면 됩니다. 
var urlencode = require('urlencode');

console.log(urlencode('변환'));
console.log(urlencode.decode('%EB%B3%80%ED%99%98'));
*/
