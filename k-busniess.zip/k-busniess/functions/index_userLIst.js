const functions = require('firebase-functions');
const firebase = require('firebase-admin');
const express = require('express');
const engines = require('consolidate');
const ejs = require('ejs');
const fs = require('fs');
const path = require('path');
const app = express();
const router = express.Router();
const bodyParser = require('body-parser');
const cors = require('cors');

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({extended:false}));


let userCount = 0;
let userList = [];

router.route('/user').post((req, res)=>{
    console.log('/user -post 호출 됨');
    
    var user = {
        id : userCount++,
        name : req.body.name,
        region : req.body.region
    }
    
    userList.push(user);
    console.log("userList.length ==> ", userList.length);
    res.send(userList);
    //res.redirect('/user');
});

router.route('/user').get((req, res)=>{
    console.log('/user get요청 받음.', userList);
    req.app.render('user_list', {"userList":userList}, (err, html)=>{
        if(err) {
            throw err;
        }
        
        res.end(html);
    });
});

router.route('/user/:id').get((req,res)=>{
    let id = req.params.id;
    
    res.end("상세보기 id => " + id);
});

router.route('/user/:id/modify').get((req,res)=>{
    let id = req.params.id;
    let modifyUser = [];
    for(let user of userList) {
        if(user.id == id) {
            modifyUser.push(user);
        }
    }
    
    if(modifyUser.length > 0) {
        req.app.render('user_modify', {"user":modifyUser[0]}, (err, html)=>{
            if(err) throw err;
            res.end(html);
        });
    } else {
        res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});
        res.end("<h2>수정하고자 하는 사용자의 정보가 없습니다!</h2>")
    }
});

router.route('/user/:id/update').get((req,res)=>{
    let id = req.params.id;
    let user = {
        id:id,
        name:req.body.name||req.query.name,
        region:req.body.region||req.query.region
    }
    
    for(let i=0; i<userList.length; i++) {
        if(userList[i].id == id) {
            userList[i] = user;
            break;
        }
    }
    
    res.redirect('/user');
});

app.use('/', router);

module.exports.app = functions.https.onRequest(app);